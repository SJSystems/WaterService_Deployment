﻿/// <reference path="~/js/General_OnLoad.js" />
/// <reference path="~/assets/js/angular.js" />

mainApp.controller('indexCambioMasivoDeListasDePreciosCtrl', ['$scope', '$http', 'abmServices',
    function ($scope, $http, abmServices) {

        $scope.onObtenerMatrizListaDePrecios = function () { };

        $scope.onObtenerDatos = function () { };


        $scope.init = function () {

        };



        $scope.init();

    }]);


mainApp.directive('matrizDeListasDePrecios', function ($http) {

    return {
        restrict: 'E',
        scope: {
            onObtenerMatrizListaDePrecios: "="
        },
        templateUrl: "/js/app/views/listaDePreciosCambioMasivo/matriz.html",

        link: function (scope, element, attrs) {

            scope.filtros = {
                tipoLista_ids: 0,
                tipoArticulo_ids: 0,
                rubro_ids : 0,
            };

            scope.editandoUnPrecio = false;

            scope.listas = [];
            scope.articulos = [];

            scope.tiposDeListasDePrecios = [];
            scope.tiposDeArticulos = [];
            scope.rubros = [];

            var init = function () {
                scope.onObtenerMatrizListaDePrecios();
            };

            scope.onObtenerMatrizListaDePrecios = function () {

                $http.get(GetUrlForService('/ListaDePrecios/GetDataForMatrizDeListaDePrecios'),
                    {}).then(function (resp) {

                        if (resp.data.error == 0) {
                            scope.tiposDeListasDePrecios = resp.data.tiposDeListasDePrecios;
                            scope.tiposDeListasDePrecios.insert(0, { valor_ids: 0, valorTexto: '-- Todos --' });

                            scope.tiposDeArticulos = resp.data.tiposDeArticulos;
                            scope.tiposDeArticulos.insert(0, { valor_ids: 0, valorTexto: '-- Todos --' });

                            scope.rubros = resp.data.rubros;
                            scope.rubros.insert(0, { valor_ids: 0, valorTexto: '-- Todos --' });
                        }
                    },
                    function (resp) { });

                $http.get(GetUrlForService('/ListaDePrecios/ObtenerMatrizListaDePrecios'),
                    {}).then(function (resp) {

                        if (resp.data.error == 0) {
                            scope.matriz = resp.data.matriz;
                        }
                    },
                    function (resp) { });
            };

            scope.editarPrecio = function (precio) {

                precio.editando = true;
                scope.editandoUnPrecio = true;
            };

            scope.onCambiarPrecio = function (precio) {

                precio.nuevoPrecio = precio.nuevoPrecio * 1;
                precio.editando = false;
                precio.precioModificado = true;
                scope.editandoUnPrecio = false;

                if (precio.precioOriginal==null)
                    precio.precioOriginal = precio.precio;

                precio.precio = precio.nuevoPrecio;                
            }

            scope.onGuardar = function () {

                bootbox.confirm("Está seguro que desea confirmar los cambios de precios?", function (resp) {
                    if (resp) {
                        scope.preciosModificados = [];

                        angular.forEach(scope.matriz.articulos, function (articulo) {

                            angular.forEach(articulo.precios, function (precio) {

                                if (precio.precioModificado == true) {
                                    scope.preciosModificados.push(
                                        {
                                            articulo_id: precio.articulo_id,
                                            lista_id: precio.lista_id,
                                            precio: precio.precio
                                        }
                                    );
                                }
                            });
                        });
                        
                        if (scope.preciosModificados.length == 0)
                        {
                            ShowMessageBox(messageType_Error, "Error.", "No hay modificaciones de precios");
                            return;
                        }

                        var url = GetUrlForService('/ListaDePrecios/CambioDePrecioPorMatriz');
                        $http.post(url,
                            {
                                precios: scope.preciosModificados
                            })
                            .then(function (resp) {

                                if (resp.data.error == 0) {
                                    ShowMessageBox(messageType_Success, "Cambios guardados con éxito.");
                                    window.location.reload();
                                }

                            }, function (resp) { });
                    }
                })

            }

            scope.onCancelarEdicion = function (precio) {

                precio.editando = false;
                scope.editandoUnPrecio = false;
                precio.nuevoPrecio = null;
            };

            scope.revertirCambioDePrecio = function (precio) {
                precio.precioModificado = false;
                precio.precio = precio.precioOriginal;
                precio.precioOriginal = null;
                precio.nuevoPrecio = null;
            };

            init();
        }
    };
});

mainApp.directive('cambioMasivoDeListasDePrecios', function ($http, abmServices) {

    return {
        restrict: 'E',
        scope: {
            onObtenerDatos: "="
        },
        templateUrl: "/js/app/views/listaDePreciosCambioMasivo/cambioDePrecios.html",
        link: function (scope, element, attrs) {

            var init = function () {

                scope.metodos = [];
                scope.cambioPrecio = {
                    listas: {},
                    articulos: {},
                    metodo_id: 0,
                };

                scope.onObtenerDatos();

                scope.obtenerMetodos();

            };

            scope.onObtenerDatos = function () {

                $http.get(GetUrlForService('/ListaDePrecios/ObtenerMatrizListaDePrecios'), {})
                    .then(function (resp) {

                        if (resp.data.error == 0) {
                            scope.listas = resp.data.matriz.listas;
                            scope.articulos = resp.data.matriz.articulos;
                        }
                    }, function (resp) { });
            };

            scope.obtenerMetodos = function () {

                scope.metodos.push({
                    metodo_id: 0,
                    descripcion: "Seleccione"
                });
                scope.metodos.push({
                    metodo_id: 1,
                    descripcion: "Aumento por porcentaje"
                });
                scope.metodos.push({
                    metodo_id: 2,
                    descripcion: "Aumento por precio final"
                });
                scope.metodos.push({
                    metodo_id: 3,
                    descripcion: "Adicionar por monto fijo"
                });

                scope.cambioPrecio.metodo_id = scope.metodos[0].metodo_id;

            };

            scope.getRequest = function () {
                
                var idsListas = scope.listas.itemsSelected.map(function (x) { return x.lista_id });
                var idsArticulos = scope.articulos.itemsSelected.map(function (x) { return x.articulo_id });

                var metodoElegido = {};

                angular.forEach(scope.metodos, function (item) {
                    
                    if (item.metodo_id == scope.cambioPrecio.metodo_id) {
                        metodoElegido = {
                            metodo_id: item.metodo_id,
                            descripcion: item.descripcion
                        };                        
                    }                    
                });

                var req = {
                    idsListas: idsListas,
                    idsArticulos: idsArticulos,
                    metodoElegido: metodoElegido,
                    precioNuevo: scope.cambioPrecio.precioNuevo

                };

                return req;

            };

            scope.onConfirmar = function () {

                alert("Esta funcionalidad estará activa en la próxima actualización del sistema");
                return;

                var url = "";
                var variableMetodo = "";

                var req = scope.getRequest();

                var cantidadListas = req.idsListas.length;
                var cantidadArticulos = req.idsArticulos.length;

                if (scope.cambioPrecio.metodo_id == 1) {
                    variableMetodo = "Porcentaje de Aumento: %";
                }
                else if (scope.cambioPrecio.metodo_id == 2) {
                    variableMetodo = "Precio Final: $ ";
                }
                else if (scope.cambioPrecio.metodo_id == 3) {
                    variableMetodo = "Monto a Adicionar: $";
                }



                bootbox.confirm(
                    "Confirma cambiar los precios de " + cantidadArticulos +
                    " artículos seleccionados en " + cantidadListas + " listas. " +
                    " Método: " + req.metodoElegido.descripcion + " " + variableMetodo + " " + req.precioMetodo + "?"

                    , function (result) {

                        if (result) {
                            ShowLoader();

                            $http.post(url, req)
                                .then(function (resp) {

                                    if (resp.data.error == 0) {

                                        HideLoader();
                                    }
                                    else {
                                        ShowMessageBox(messageType_Error, "Error", resp.data.message);
                                    }
                                }, function (resp) {
                                    HideLoader();
                                    ShowMessageBox(messageType_Error, "Error", "Se ha producido un error");
                                });

                            HideLoader();
                        }
                    });

            };

            init();

        }
    };
});

mainApp.directive('uiSeleccionarListasDePrecios', function ($http) {

    return {
        restrict: 'E',
        scope: {
            dirModel: "=",
            optionItems: "=?",
            multiple: "@",
            allowClear: "@"
        },
        templateUrl: "/js/app/views/shared/template_seleccionar_listasDePrecios_ui.html",
        link: function (scope, element, attrs) {
                        
            if (scope.dirModel == null) scope.dirModel = {};
            if (scope.dirModel.itemsSelected == null) scope.dirModel.itemsSelected = [];

            var init = function (textoBuscado) {

                return $http.get(GetUrlForService('/ListaDePrecios/ObtenerMatrizListaDePrecios')
                ).then(
                    function (resp) {
                        
                        scope.optionItems = resp.data.matriz.listas;
                    });
            };

            init();
        }
    };
});

mainApp.directive('uiSeleccionarArticulosListasDePrecios', function ($http) {

    return {
        restrict: 'E',
        scope: {
            dirModel: "=",
            optionItems: "=?",
            multiple: "@",
            allowClear: "@"
        },
        templateUrl: "/js/app/views/shared/template_seleccionar_articulosDeListasDePrecios_ui.html",
        link: function (scope, element, attrs) {
                        
            if (scope.dirModel == null) scope.dirModel = {};
            if (scope.dirModel.itemsSelected == null) scope.dirModel.itemsSelected = [];

            var init = function (textoBuscado) {

                return $http.get(GetUrlForService('/ListaDePrecios/ObtenerMatrizListaDePrecios')
                ).then(
                    function (resp) {
                        
                        scope.optionItems = resp.data.matriz.articulos;
                    });
            };

            init();
        }
    };
});

mainApp.filter('propsFilter', function propsFilter() {

    return filterFilter;

    function filterFilter(items, props) {
        var out = [];

        if (angular.isArray(items)) {
            items.forEach(function (item) {
                var itemMatches = false;

                var keys = Object.keys(props);
                for (var i = 0; i < keys.length; i++) {
                    var prop = keys[i];

                    if (props[prop] == null || props[prop] == undefined) return out;

                    var text = props[prop].toLowerCase();
                    if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                        itemMatches = true;
                        break;
                    }
                }

                if (itemMatches) {
                    out.push(item);
                }
            });
        } else {
            // Let the output be the input untouched
            out = items;
        }

        return out;
    }
});




