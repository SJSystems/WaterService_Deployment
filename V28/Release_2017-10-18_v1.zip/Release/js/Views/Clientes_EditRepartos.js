﻿/// <reference path="../General_OnLoad.js" />

var Modelo = {
    Init: function() {

        $("#tabs_repartos").tabs();
    }
};

